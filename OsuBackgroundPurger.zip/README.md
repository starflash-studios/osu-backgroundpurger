# osu!backgroundpurger
 A simple C#.NET WPF program allowing one to remove the background (images and videos) of osu!beatmaps in bulk.
