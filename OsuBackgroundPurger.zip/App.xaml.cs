﻿namespace OsuBackgroundPurger {
    public partial class App { }
}
